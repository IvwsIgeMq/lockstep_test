------------------------------------------------------------------
-- MonsterAI.lua
-- Author     : liyongguang
-- Date       : 2015-08-17
-- Description: 怪物AI
------------------------------------------------------------------

local MonsterAI = class("MonsterAI")



return MonsterAI
